#TicTac Game

Welcome to a 'TicTac Game'!! 
This is a small software package through which can play TicTac game

# What does this 'TicTac game' do ?

This software is written to enjoy the game of 'TicTac' on computer. Command line user interface will help you to play game

# How to Use ?

* On installation it will display the instructions on screen and you can enjoy the game !!!

P.S. Please do visit requirements.txt prior execution of code
